import React from 'react';

function App() {
  // Display "Hello World!" in a paragraph
  const helloWorld = <p>Hello World!</p>;

  // Create a constant variable with JSX
  const myelement = <h1>I Love JSX!</h1>;

  // Create a constant variable named sum
  const sum = 5 + 5;

  return (
    <div>
      {/* Render the Hello World paragraph */}
      {helloWorld}

      {/* Render the JSX element */}
      {myelement}

      {/* Render the sentence with the sum */}
      <p>React is {sum} times better with JSX</p>
    </div>
  );
}

export default App;
