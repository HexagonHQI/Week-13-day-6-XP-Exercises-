import React from 'react';
import Exercise from './Exercise3'; // Import the Exercise component

function App() {
  return (
    <div className="App">
      <Exercise />
    </div>
  );
}

export default App;
